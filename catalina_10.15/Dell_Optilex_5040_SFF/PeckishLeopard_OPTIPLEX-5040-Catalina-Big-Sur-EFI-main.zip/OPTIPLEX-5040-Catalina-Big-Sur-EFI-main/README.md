# OPTIPLEX5040
Dell Optiplex 5040 Big Sur/Catalina EFI Folder

This EFI folder has only ever been used to Install OSX Catalina, however once installed it is possible to upgrade to Big Sur with no subsequent changes. I suspect installing Big Sur from the get go will also work however this is yet to be tested.


-----IMPORTANT:----
FOR DEBUG MODE/INITIAL OSX INSTALL USE EFI IN DEBUG FOLDER. ONCE INSTALLED AND FULLY TESTED, COPY THE EFI FOLDER IN THE RELEASE FOLDER TO THE EFI PARTITION OF YOUR OPTIPLEX HDD. This will enable much smoother boots, and stop a bootlog being produced each time your machine boots. 
-------------------






