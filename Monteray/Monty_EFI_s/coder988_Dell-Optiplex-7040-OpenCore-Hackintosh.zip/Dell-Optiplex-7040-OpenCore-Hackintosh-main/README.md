# Dell-Optiplex-7040-OpenCore-Hackintosh

Dell Optiplex 7040 OpenCore 0.6.3 EFI.  Tested with Catalina 10.15.7 and Big Sur beta.

CPU:  I5-6500
Video:  iGPU HD530 (does not support full 4K ouput)
Memory:  8GB (2x4GB)
Disk:  Kingston 120GB SSD

iGPU does not work with sleep.  
