# Document Statement

## templates

Template files for this theme

## common

Some common variables and code snippets are designed to be shared by multiple themes
