---
sort: 9
---

# Credits
* The [Acidanthera](https://github.com/acidanthera/) team -- OpenCore(!), WhatEverGreen, Lilu, VirtualSMC, AppleALC, etc, etc. Amazing work.
* [Dortania](https://dortania.github.io/OpenCore-Install-Guide/config.plist/haswell.html) -- Vanilla Desktop Guide, without this I wouldn't have gotten far.
* [headkaze](https://github.com/headkaze) -- Hackintool (an essential) and EFI-Agent is pretty sweet too.
* [corpnewt](https://github.com/corpnewt) -- Many essential tools, guides/documentation, simply great!
* And many, many more I forgot.

A deep bow to all of you!

