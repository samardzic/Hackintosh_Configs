# OptiHack

Welcome to my OptiHack Hackintosh guide. This guide is meant for Dell Optiplex 7020/9020 systems. Please use the sidebar on the left to navigate the guide.

This guide assumes macOS will be the only OS and any disk installed in the system can be wiped. Disconnect any Windows and Linux disks before installing to prevent any issues. You can re-connect them post install and then use the BIOS boot menu (F12) to multiboot.

This guide is made for fun and my own edutainment.
