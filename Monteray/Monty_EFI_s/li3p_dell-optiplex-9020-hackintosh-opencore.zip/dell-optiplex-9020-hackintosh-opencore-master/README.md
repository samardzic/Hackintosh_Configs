# OptiHack
Dell OptiPlex 7020/9020 hackintosh stuff.

![Montedell](/images/Monterey.png?raw=true)

# New guide can be found [here](https://zearp.github.io/OptiHack/).

## PSA: From the 24th of June 2021 the default SMBIOS has been changed. This means that when you update you will either have generate new serials and before doing so logout from the iMessage and Facetime apps as well as iCloud itself. Or you can of course change the SMBIOS back to iMac15,1 or iMac14,3, if you do so you'll also need edit the plist inside USBPorts.kext to match the new model. This change is done so we can install Monterey.
