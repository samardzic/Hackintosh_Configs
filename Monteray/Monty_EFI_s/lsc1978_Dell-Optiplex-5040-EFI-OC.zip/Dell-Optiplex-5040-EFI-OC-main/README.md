# Optiplex-5040-EFI-OC

OpenCore EFI for Dell Optiplex 5040 with Big Sur(11.0.1)
